const app = require('./app');
const port = 3000;

app.listen(port, () => {
  console.log(`Lloyds branch service listening on port ${port}`);
});
