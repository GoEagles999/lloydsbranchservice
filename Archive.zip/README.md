# Lloyds branches service

Run 'npm start' and then curl -H "lbg-txn-branch-location: london" localhost:3000/branch to test

Run 'npm run test' to run tests